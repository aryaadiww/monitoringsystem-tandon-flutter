<?php
// Konfigurasi database
include '../koneksi.php'; // Pastikan koneksi ke database sudah benar

// Cek koneksi
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Koneksi gagal: ' . $conn->connect_error]));
}

// Mengambil ID dari request
$id = $_POST['id'] ?? '';

// Validasi input
if (empty($id)) {
    echo json_encode(['success' => false, 'message' => 'ID tidak boleh kosong']);
    exit;
}

// Menghapus data laporan dari database
$sql = "DELETE FROM laporanKerusakan WHERE id_laporan = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Laporan berhasil dihapus']);
} else {
    echo json_encode(['success' => false, 'message' => 'Gagal menghapus laporan: ' . $stmt->error]);
}

// Menutup koneksi
$stmt->close();
$conn->close();
?>
