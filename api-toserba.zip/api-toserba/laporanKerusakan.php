<?php
// Konfigurasi database
include '../koneksi.php'; // Pastikan koneksi ke database sudah benar

// Cek koneksi
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Koneksi gagal: ' . $conn->connect_error]));
}

// Mengambil data dari request
$kode_alat = $_POST['kode_alat'] ?? '';
$tanggal = $_POST['tanggal'] ?? '';
$jenis_kerusakan = $_POST['jenis_kerusakan'] ?? '';
$deskripsi = $_POST['deskripsi'] ?? '';

// Validasi input
if (empty($kode_alat) || empty($tanggal) || empty($jenis_kerusakan) || empty($deskripsi)) {
    echo json_encode(['success' => false, 'message' => 'Semua field harus diisi']);
    exit;
}

// Menyimpan data ke database
$sql = "INSERT INTO laporanKerusakan (kode_alat, tanggal, jenis_kerusakan, deskripsi) VALUES (?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssss", $kode_alat, $tanggal, $jenis_kerusakan, $deskripsi);

if ($stmt->execute()) {
    echo json_encode(['success' => true, 'message' => 'Laporan berhasil dikirim']);
} else {
    echo json_encode(['success' => false, 'message' => 'Gagal mengirim laporan: ' . $stmt->error]);
}

// Menutup koneksi
$stmt->close();
$conn->close();
?>