<?php
include '../koneksi.php';

// Enable error reporting untuk debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: application/json');

// Tangkap data POST
$oldUsername = isset($_POST['old_username']) ? $_POST['old_username'] : '';
$newUsername = isset($_POST['new_username']) ? $_POST['new_username'] : '';
$email = isset($_POST['email']) ? $_POST['email'] : '';
$password = isset($_POST['password']) ? $_POST['password'] : '';

// Log data yang diterima
error_log("Data diterima - Old: $oldUsername, New: $newUsername, Email: $email");

// Validasi data
if (empty($oldUsername) || empty($newUsername) || empty($email)) {
    echo json_encode([
        "status" => "failed",
        "message" => "Data tidak lengkap"
    ]);
    exit;
}

try {
    // Cek koneksi database
    if ($conn->connect_error) {
        throw new Exception("Koneksi database gagal: " . $conn->connect_error);
    }

    // Update tabel members
    $updateQuery = "UPDATE members SET email = ?";
    $params = [$email];
    $types = "s";

    if (!empty($password)) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $updateQuery .= ", password = ?";
        $params[] = $hashedPassword;
        $types .= "s";
    }

    if ($oldUsername !== $newUsername) {
        $updateQuery .= ", username = ?";
        $params[] = $newUsername;
        $types .= "s";
    }

    $updateQuery .= " WHERE username = ?";
    $params[] = $oldUsername;
    $types .= "s";

    $stmt = $conn->prepare($updateQuery);
    if (!$stmt) {
        throw new Exception("Prepare statement error: " . $conn->error);
    }

    $stmt->bind_param($types, ...$params);
    $executeResult = $stmt->execute();

    if (!$executeResult) {
        throw new Exception("Execute error: " . $stmt->error);
    }

    // Update username di tabel alat jika username berubah
    if ($oldUsername !== $newUsername) {
        $conn->query("UPDATE alat SET username_member = '$newUsername' WHERE username_member = '$oldUsername'");
    }

    echo json_encode([
        "status" => "success",
        "message" => "Profil berhasil diperbarui",
        "user" => [
            "username" => $newUsername,
            "email" => $email
        ]
    ]);

} catch (Exception $e) {
    error_log("Error in editAkun.php: " . $e->getMessage());
    
    echo json_encode([
        "status" => "failed",
        "message" => "Gagal memperbarui profil: " . $e->getMessage()
    ]);
} finally {
    if (isset($stmt)) $stmt->close();
    if (isset($conn)) $conn->close();
}
?>
