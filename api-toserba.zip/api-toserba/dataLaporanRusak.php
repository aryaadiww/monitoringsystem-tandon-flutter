<?php
// Konfigurasi database
include '../koneksi.php'; // Pastikan koneksi ke database sudah benar

// Cek koneksi
if ($conn->connect_error) {
    die(json_encode(['success' => false, 'message' => 'Koneksi gagal: ' . $conn->connect_error]));
}

// Mengambil kode_alat dari request
$kode_alat = $_POST['kode_alat'] ?? '';

// Validasi input
if (empty($kode_alat)) {
    echo json_encode(['success' => false, 'message' => 'Kode alat tidak boleh kosong']);
    exit;
}

// Mengambil data laporan dari database
$sql = "SELECT * FROM laporanKerusakan WHERE kode_alat = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $kode_alat);
$stmt->execute();
$result = $stmt->get_result();

$laporanList = [];
while ($row = $result->fetch_assoc()) {
    $laporanList[] = $row;
}

echo json_encode(['success' => true, 'data' => $laporanList]);

// Menutup koneksi
$stmt->close();
$conn->close();
?>